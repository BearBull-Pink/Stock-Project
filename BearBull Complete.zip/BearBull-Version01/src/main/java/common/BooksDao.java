package common;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
public class BooksDao {
	
	
	    Connection con;

	    public BooksDao(Connection con) {
	        this.con = con;
	    }
	    
	    
	    //add books information to database
	    public boolean addBook(books book){
	        boolean test = false;
	        
	        try{
	            String query =  "insert into books (bName,bDesc,aName, aName1) values(?,?,?,?)";
	            PreparedStatement pst = this.con.prepareStatement(query);
	            pst.setString(1, book.getBookName());
	            pst.setString(2, book.getBookDesc());
	            pst.setString(3, book.getAuthName());
	            pst.setFloat(4, book.getAuthName1());
	         
	            pst.executeUpdate();
	            test= true;

	        }catch(Exception e){
	            e.printStackTrace();
	        }
	        return test;
	    }
	    
//	    retrieve the book details from databse
	    public List<books> getAllBooks(){
	        List<books> book = new ArrayList<>();
	        
	        try{
	            
	            String query = "select * from books";
	            PreparedStatement pt = this.con.prepareStatement(query);
	            ResultSet rs = pt.executeQuery();
	            
	            while(rs.next()){
	                int id = rs.getInt("id");
	                String bname = rs.getString("bName");
	                String des = rs.getString("bDesc");
	                String aname = rs.getString("aName");
	                float aname1 = rs.getFloat("aName1");
	             
	                
	                books row = new books(id,bname,des,aname,aname1);
	                book.add(row);
	            }
	            
	        }catch(Exception e){
	            e.printStackTrace();;
	        }
	        return book;
	    }
	    
	    
//	    eidt book information
	    public  boolean  editBookInfo(books book) throws SQLException  {
	    	boolean rowUpdated = false;
	        try{
	            String query = "update books set bName=?, bDesc=?, aName=?, aName1=? where id=?";
	            PreparedStatement pt = this.con.prepareStatement(query);
	            pt.setString(1, book.getBookName());
	            pt.setString(2, book.getBookDesc());
	            pt.setString(3, book.getAuthName());
	            pt.setFloat(4, book.getAuthName1());
	       
	            pt.setInt(5, book.getId());
	            
	            rowUpdated = pt.executeUpdate() > 0;
	            
	           // pt.executeUpdate();
	          
	        }
	         catch(Exception ex){
	            ex.printStackTrace();;
	        }
	        return rowUpdated;
	        
	    }
	    
//	    get single book information in edit page
	    public books getSingleBook(int id){
	        books bk = null;
	        
	        try{
	            String query = "select * from books where id=? ";
	            
	            PreparedStatement pt = this.con.prepareStatement(query);
	            pt.setInt(1, id);
	            ResultSet rs= pt.executeQuery();
	            
	            while(rs.next()){
	                int bid = rs.getInt("id");
	                String bnm = rs.getString("bName");
	                String bdes = rs.getString("bDesc");
	                String anm = rs.getString("aName");
	               float anm1 = rs.getFloat("aName1");
	              
	                bk = new books(bid,bnm,bdes,anm,anm1);
	            }
	        }catch(Exception ex){
	            ex.printStackTrace();;
	        }
	        return bk;
	    }
	    
	    
//	    delete books from database
	    
	    
	    public void deleteBook(int id){
	        try{
	            
	           String query= "delete from books where id=?";
	           PreparedStatement pt = this.con.prepareStatement(query);
	           pt.setInt(1, id);
	           pt.execute();
	            
	        }catch(Exception ex){
	            ex.printStackTrace();;
	        }
	    }
	}


