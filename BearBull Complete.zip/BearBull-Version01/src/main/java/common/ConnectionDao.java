package common;
import java.sql.*;

public class ConnectionDao {
	
	
	    private static Connection con;

	    public static Connection getCon() throws SQLException {
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/curd_project","root","1234");
	        }catch (Exception ex) {
	            ex.printStackTrace();
	        } 
	        return con;
	    }
	}


