package common;

public class books {
	

	    int id;
	    String bookName;  //company
	    String bookDesc;  //market
	    String authName;   //low
	    Float authName1;   //high
	    

	    public books() {
	    }

	    public books(int id, String bookName, String bookDesc, String authName, Float authName1) {
	        this.id = id;
	        this.bookName = bookName;
	        this.bookDesc = bookDesc;
	        this.authName = authName;
	        this.authName1 = authName1;
	     
	    }

	    public books(String bookName, String bookDesc, String authName, Float authName1) {
	        this.bookName = bookName;
	        this.bookDesc = bookDesc;
	        this.authName = authName;
	        this.authName1 = authName1;
	       
	    }

	    public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }

	    public String getBookName() {
	        return bookName;
	    }

	    public void setBookName(String bookName) {
	        this.bookName = bookName;
	    }

	    public String getBookDesc() {
	        return bookDesc;
	    }

	    public void setBookDesc(String bookDesc) {
	        this.bookDesc = bookDesc;
	    }

	    public String getAuthName() {
	        return authName;
	    }

	    public void setAuthName(String authName) {
	        this.authName = authName;
	    }
	    
	    public float getAuthName1() {
	        return authName1;
	    }

	    public void setAuthName1(float authName1) {
	        this.authName1 = authName1;
	    }

	    @Override
	    public String toString() {
	        return "books{" + "id=" + id + ", bookName=" + bookName + ", bookDesc=" + bookDesc + ", authName=" + authName +", authName1=" + authName1+ '}';
	    }
	    
	    
	}


