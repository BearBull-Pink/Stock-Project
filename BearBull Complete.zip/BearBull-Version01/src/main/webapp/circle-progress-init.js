(function ($) {
    "use strict";


  $('#visitor-circle').circleProgress({
    value: 0.75,
    size: 100,
    fill: {
      gradient: ["#03a9f5", "#1de9b6"]
    }
  });
    
    
    
     $('#bounce-circle').circleProgress({
    value: 0.75,
    size: 100,
    fill: {
      gradient: ["#03a9f5", "#1de9b6"]
    }
  });
    
    
    
     $('#growth-circle').circleProgress({
    value: 0.75,
    size: 100,
    fill: {
      gradient: ["#03a9f5", "#1de9b6"]
    }
  });
    
    
    
     $('#pageviews-circle').circleProgress({
    value: 0.75,
    size: 100,
    fill: {
      gradient: ["#03a9f5", "#1de9b6"]
    }
  });

    $('#primary-circle-card').circleProgress({
        value: 0.50,
        size: 100,
        fill: {
            gradient: ["#03a9f5"]
        }
    });
    $('#danger-circle-card').circleProgress({
        value: 0.80,
        size: 100,
        fill: {
            gradient: ["#f44236"]
        }
    });
    $('#info-circle-card').circleProgress({
        value: 0.70,
        size: 100,
        fill: {
            gradient: ["#a389d5"]
        }
    });
    
    
    
    
    
    
    
    
    
    
    
    
    
    

})(jQuery);