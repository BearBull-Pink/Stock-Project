//first request to server to create order

const paymentStart=()=>{
    console.log("payment started..");
    let amount=$("#payment_field").val()
    console.log(amount);
    if(amount=='' || amount==null)
    {
        alert("amount is required");
        return;
    }

    //code..
    //we used ajax to send request to server to create oreder- jquery

    $.ajax(
        {
            url='/user/create_order',
            data: JSON.stringify({amount:amount, info:'order_request'}),
            contentType:'application/json',
            type: 'POST',
            dataType:'json',
            success:function(response){
                //invoked when success
                console.log(response)
            },
            error:function(error)
            {
                //invoke when failed
                console.log(error)
                alert("something went wrong")
            }
        }
    )
};